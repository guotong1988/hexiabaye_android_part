--[[

    游戏启动Scene，主要就是初始化GameStartUI

--]]

local GameStartUI = require("module.studio_ui.game_start_ui")

local GameStartScene = class("GameStartScene", function()
  return display.newScene("GameStartScene")
end)

GameStartScene.ctor = function(self)
  self.handlers = {
    [EventConst.START_UI] = handler(self, GameStartScene.startUI),
  }
  for k, v in pairs(self.handlers) do
    EventMgr.registerEvent(k, v)
  end
  
  GameData.startScene=self
  GameStartUI.new():addTo(self)

end

GameStartScene.startUI = function(self)
  while GameData.remove==nil or GameData.remove==false do 
  end
  GameData.removeMapView()
  GameData.removed = true
  GameStartUI.new():addTo(self)
end

GameStartScene.onExit = function(self)
  EventMgr.triggerEvent(EventConst.SCENE_EXIT)
end





return GameStartScene
