ccexp = ccexp or {}


ccexp.VideoPlayerEvent = {
    PLAYING = 0,
    PAUSED = 1,
    STOPPED= 2,
    COMPLETED =3,
}
